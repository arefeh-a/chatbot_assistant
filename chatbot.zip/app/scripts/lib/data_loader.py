import logging
from pathlib import Path
from typing import List
from langchain_core.documents import Document

logger = logging.getLogger(__name__)

class DataLoader:
    """
    Loads a single document from a specified file path.
    This class is instantiated for each file by the build_kb script.
    """

    def __init__(self, file_path: Path):
        """
        Initializes the DataLoader with the path to a specific file.

        Args:
            file_path (Path): The path to the .txt file to load.
        """
        self.file_path = file_path
        if not self.file_path.is_file():
            logger.warning(f"File not found during init: {self.file_path}")

    def load(self) -> List[Document]:
        """
        Loads the single file content and returns it as a list 
        containing one LangChain Document.

        Returns:
            List[Document]: A list containing the single loaded document.
        """
        logger.debug(f"Loading document: {self.file_path.name}")
        documents: List[Document] = []
        
        try:
            with open(self.file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Create a Document object
            doc = Document(
                page_content=content,
                metadata={"source": str(self.file_path.name)}
            )
            documents.append(doc)

        except Exception as e:
            logger.error(f"Failed to read {self.file_path.name}: {e}")

        # Return a list, as expected by build_kb.py's .extend() method
        return documents